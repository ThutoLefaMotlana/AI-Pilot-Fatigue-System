# AI-Enabled Pilot Fatigue Detection & Safety System

Real-time fatigue detection prototype that watches a pilot's (or driver's) face through the camera, optionally reads heart rate from a Garmin/BLE chest strap, turns the signals into a 0–100 fatigue score, raises staged audio alerts, and logs every session to a backend with an analytics dashboard.

> Final-year project, **Belgium Campus iTversity** – Aviation Safety Programme, 2026 (team project, see [Team](#team)).

## Features

- **Face monitoring** – Google ML Kit face detection on the live camera feed: eye aspect ratio (EAR), blink rate, PERCLOS, slow blinks, microsleeps, yawns and head nods.
- **Fatigue score (0–100)** – weighted blend of those signals plus heart-rate deviation from a personal baseline; rises over seconds, decays over minutes, with level hysteresis (`normal → warning → high → critical`).
- **Heart-rate strap** – connects to any standard BLE Heart Rate Service device (Garmin HRM-Dual / Pro / 600 etc.).
- **Staged alerts** – 3 beeps (warning), 5 beeps (high), continuous alarm (critical), plus advisory beeps before predicted risky periods.
- **Learned driving limits** – the backend works out a recommended break interval and "danger zones" (hour of day × time into drive) from past sessions, and the app warns before you reach them.
- **Simulator** – built-in scenarios (normal ↔ warning / high / critical / full cycle) so everything can be demoed without a tired person.
- **Backend + dashboard** – sessions, readings and events stored in MongoDB; password-protected web dashboard showing events by time of day, danger map, break recommendation, heart rate before events and per-drive timelines.

## Architecture

```
 Camera ─┐
         ├─► Flutter app ──► fatigue estimator ──► alerts (audio)
 BLE HR ─┘        │
                  └── HTTPS/JSON ──► Node.js + Express API ──► MongoDB
                                              │
                                              └──► Web dashboard (/dashboard)
```

| Path | What it is |
|---|---|
| `lib/ai/` | Camera + ML Kit pipeline (`fatigue_monitor.dart`) and the pure-Dart scoring logic (`fatigue_estimator.dart`, unit-tested) |
| `lib/sensors/` | BLE heart-rate monitor |
| `lib/alerts/` | Alarm/beep player and driving-limit advisor |
| `lib/sim/` | Fatigue simulator |
| `lib/services/` | Backend API client |
| `backend/` | Express + Mongoose REST API, analytics, dashboard, tests – see [`backend/README.md`](backend/README.md) and [`backend/DATABASE.md`](backend/DATABASE.md) |
| `test/` | Flutter unit/widget tests |

## Getting started

### 1. Backend

Requires Node.js 18+ and MongoDB.

```bash
cd backend
cp .env.example .env     # set MONGODB_URI, DASHBOARD_PASSWORD, ...
npm install
npm run dev              # http://localhost:3000/api/health
npm test                 # 10 API tests, no database needed
npm run demo:add         # optional: 4 weeks of fake drives for the dashboard
```

Dashboard: <http://localhost:3000/dashboard/>

### 2. Flutter app

Requires the Flutter SDK (Dart `^3.13`) and a phone/emulator with a camera.

```bash
flutter pub get
flutter run --dart-define=BACKEND_URL=http://<your-pc-ip>:3000/api
flutter test
```

`BACKEND_URL` is a compile-time setting; if omitted the app falls back to the default in `lib/services/backend_service.dart`. Point it at your own backend for any real use. Android emulator: `http://10.0.2.2:3000/api`.

## Testing

- Backend: `cd backend && npm test` (Node test runner + supertest, in-memory model stand-ins).
- App: `flutter test` covers the fatigue estimator, simulator, heart-rate parsing and limit advisor.

## Project report vs. this prototype

The accompanying project report specifies a full hardware design: Raspberry Pi 5, Pi Camera Module 3, MAX30102 SpO₂ sensor, GPIO buzzer/LED/haptic staged alerts, a 3D-printed ABS enclosure, Firebase/AWS IoT cloud and a React ground-control dashboard.

This repository contains the **software prototype** of that system, implemented with a different stack so it can be demonstrated on a phone:

| Report | Implemented here |
|---|---|
| Raspberry Pi 5 + OpenCV/TFLite | Flutter app + Google ML Kit face detection |
| Garmin HR strap / MAX30102 | Garmin (any BLE HR) strap |
| GPIO buzzer, LED, haptic | Phone audio alerts |
| Firebase / AWS IoT | Node.js + Express + MongoDB |
| React dashboard, JWT auth | Static HTML/JS dashboard (Chart.js), password auth |
| 3D-printed enclosure | Not part of this repo |

Fatigue thresholds are tuned heuristics, **not a validated or certified safety device** and must not be relied on in real flight or driving.

## Team

Belgium Campus iTversity, 2026: Dristen Erasmus Albertus Venter, Unathi Baholo, Koketso Lebelo, Nokutenda Madziwa, Thuto Lefa Motlana, Katlego Lethole, Kgalalelo Molepo, Busisiwe Socatsha.
